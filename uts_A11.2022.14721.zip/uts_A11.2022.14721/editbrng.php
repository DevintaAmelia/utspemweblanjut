<?php 
    include "koneksi.php";
    $id=$_GET['id'];
    $sql="select * from data where id='$id'";
    $hasil= $conn->query($sql);
    while ($row=$hasil->fetch_assoc()){
        $nama=$row['nama'];
        $hrg=$row['hrg'];
        $stok=$row['tstok'];
        $keterangan=$row['keterangan'];
        $foto=$row['foto'];
    }
?>
<html>
    <head>
         <!-- Required meta tags -->
     <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    
    <link rel="stylesheet" href="style.css">
    </head>
    <body>
        

        <div class="container">
        <h2 class="alert alert-primary text-center mt-3">EDIT DATA BARANG</h2>
        <form action='updBrng.php' method='post' enctype="multipart/form-data">
            <div class="form-group">
                <label>ID</label>
                <input type="text" name="tid" class="form-control" value="<?= $id; ?>">
            </div>
            <div class="form-group">
                <label>Nama Barang</label>
                <input type="text" name="tnama" class="form-control" value="<?= $nama; ?>">
            </div>
            <div class="form-group">
                <label>Harga</label>
                <input type="text" name="thrg" class="form-control" value="<?= $hrg; ?>">
            </div>
            <div class="form-group">
                <label>Stok</label>
                <input type="text" name="tstok" class="form-control" value="<?= $stok; ?>">
            </div>
            <div class="form-group">
                <label>Keterangan</label>
                <input type="text" name="tket" class="form-control" value="<?= $keterangan; ?>">
            </div>
            <div class="form-group">
                <label>Foto</label>
                <input type="file" name="foto" class="form-control">
            </div>
            <div class="form-group">
            <input type="hidden" name="foto_lama" value="<?= $foto; ?>">
            </div>
            <div class="form-group">
            <img src="img/<?php echo $foto; ?>" width="150px" height="120px" /><br>
            </div>
           
            <div class="form-group">
                <input type="checkbox" class="form-input-group"  value="true" >
                <label>
                Ceklist jika ingin mengubah foto
            </label>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>

    </div>
    </form>
    </div>
    </body>
</html>