<?php include('koneksi.php'); ?>
<html>
    <head>
        <title>barang</title>
        <style type="text/css">
            * {
            font-family: "Trebuchet MS";
        }
        h1 {
            text-transform: uppercase;
            color: skyblue;
        }
        .base {
            width: 400px;
            padding: 20px;
            margin-left: auto;
            margin-right: auto;
            background-color: #ededed;
        }
        label {
            margin-top: 10px;
            float: left;
            text-align: left;
            width: 100%;
        }
        input {
            padding: 6px;
            width: 100%;
            box-sizing: border-box;
            background-color: #f8f8f8;
            border: 2px solid #ccc;
            outline-color: skyblue;
        }
        button {
            background-color: skyblue;
            color: #fff;
            padding: 10px;
            font-size: 12px;
            border: 0;
            margin-top: 20px;
        }
        </style>
    </head>
    <body>
        <center><h1>Tambah Produk</h1></center>
        <form method="POST" action="insBrg.php" enctype="multipart/form-data">
        <section class="base">
            <div>
                <label>ID</label>
                <input type="text" name="tid" />
            </div>
            <div>
                <label>Nama Produk</label>
                <input type="text" name="tnama" autofocus="" required="" />
            </div>
            <div>
                <label>Harga</label>
                <input type="text" name="thrg" required="" />
            </div>
            <div>
                <label>Jumlah Stok</label>
                <input type="text" name="tstok" />
            </div>
            <div>
                <label>Keterangan</label>
                <input type="text" name="tket" required="" />
            </div>
            <div>
                <label>Gambar</label>
                <input type="file" name="foto" required="" />
            </div>
            <div>
                <button type="submit">Simpan</button>
            </div>


        </section>
        </form>
</body>
</html>