<?php
    include('koneksi.php');
    include('uploadFoto.php'); 

    $id = $_POST['tid'];
    $nama = $_POST['tnama'];
    $hrg = $_POST['thrg'];
    $keterangan = $_POST['tket'];
    $stok = $_POST['tstok'];

    if (upload_foto ($_FILES["foto"])) {
    $foto=$_FILES["foto"]["name"]; 
    $sql="insert into barang (id, nama, hrg, stok, keterangan, foto) values ('$id', '$nama', $hrg, $stok, '$keterangan', '$foto')";
    if ($conn->query($sql) === TRUE) { 
        $conn->close();
        header("location:index.php");
    }
    else{
        $conn->close();
        echo "File baru gagal diupload";
    } 
    }else
    echo "Mohon maaf terdapat kesalahan dalam mengupload file.";
?>
